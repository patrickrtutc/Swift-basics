//
//  CountryListViewModel.swift
//  SearchableCountryListUIKitCombine
//
//  Created by Patrick Tung on 2/28/25.
//

import Foundation
import Combine

class CountryListViewModel: ObservableObject {
    // Published properties for reactive updates
    @Published var searchText: String = ""
    @Published var filteredCountries: [Country] = []
    
    // Private properties
    private var allCountries: [Country] = []
    private let repository: CountryRepositoryProtocol
    private var cancellables = Set<AnyCancellable>()
    
    init(repository: CountryRepositoryProtocol) {
        self.repository = repository
        setupBindings()
    }
    
    // Fetch countries from the repository
    func fetchCountries() {
        repository.getCountries()
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                if case .failure(let error) = completion {
                    print("Error fetching countries: \(error)")
                }
            }, receiveValue: { [weak self] countries in
                self?.allCountries = countries
                self?.filteredCountries = countries
            })
            .store(in: &cancellables)
    }
    
    // Set up Combine bindings for search filtering
    private func setupBindings() {
        $searchText
            .debounce(for: .milliseconds(300), scheduler: DispatchQueue.main) // Reduce filtering frequency
            .removeDuplicates() // Avoid redundant updates
            .sink { [weak self] searchText in
                self?.filterCountries(with: searchText)
            }
            .store(in: &cancellables)
    }
    
    // Filter countries based on search text
    private func filterCountries(with searchText: String) {
        if searchText.isEmpty {
            filteredCountries = allCountries // Show all countries if search is empty
        } else {
            filteredCountries = allCountries.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        }
    }
}
