import SwiftUI

@main
struct PizzaMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
