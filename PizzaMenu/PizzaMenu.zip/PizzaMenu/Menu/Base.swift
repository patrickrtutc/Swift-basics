import Foundation

struct Base {
    let name: String
    let isVegan: Bool
    let allergens: [String]
}
