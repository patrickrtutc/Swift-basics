//
//  SearchableCountryListApp.swift
//  SearchableCountryList
//
//  Created by Patrick Tung on 2/24/25.
//

import SwiftUI

@main
struct SearchableCountryListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
